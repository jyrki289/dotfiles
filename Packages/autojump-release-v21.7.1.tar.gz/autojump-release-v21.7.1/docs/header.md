## NAME

autojump - a faster way to navigate your filesystem

## SYNOPSIS

Jump to a previously visited directory that contains 'foo':

    j foo

Jump to a previously visited subdirectory of the current directory:

    jc bar

Show database entries and their respective key weights:

    j --stat

## DESCRIPTION

autojump is a faster way to navigate your filesystem. It works by maintaining a
database of the directories you use the most from the command line. Directories
must be visited first before they can be jumped to.

## DEVELOPMENT

The source code is primarily in `./bin/autojump`. Various shell wrapper scripts
are also available in `./bin/`.

Documentation is in various files under `./docs/`. Build documentation with the
command:

    make docs
